//import $ from 'jquery';
//import whatInput from 'what-input';



//window.$ = $;


window.jQuery = window.$ = $

// If you want to pick and choose which modules to include, comment out the above and uncomment
// the line below
//import './lib/dependencies';
import './lib/general.js'; 

