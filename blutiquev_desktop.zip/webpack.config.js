
module.exports = {
  externals: {
    jquery: 'jquery'
  },
};
